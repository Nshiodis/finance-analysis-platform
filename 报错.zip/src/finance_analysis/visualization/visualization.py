import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import PercentFormatter
import finance_analysis.analysis.risk_analysis as risk_analysis
import finance_analysis.utils.utils as utils
import finance_analysis.analysis.portfolio as portfolio


def plot_price_indicator(
    df,
    file_name: str,
    price_column="close",
    indicator_column="MA20",
):
    """
    绘制价格与技术指标
    
    参数:
        df: 股票数据DataFrame
        price_column: 价格列，默认close
        indicator_column: 指标列，默认MA20
        file_name: 图片文件名
    """

    plt.figure(figsize=(12, 6))

    plt.plot(
        df.index,
        df[price_column],
        label=price_column
    )

    plt.plot(
        df.index,
        df[indicator_column],
        label=indicator_column
    )

    plt.title(
        f"{price_column} and {indicator_column}"
    )

    plt.legend()

    plt.xticks(rotation=45)

    plt.tight_layout()

    utils.save_plot(plt.gcf(), file_name)

    plt.show()


def plot_return_distribution(
    df,
    file_name: str,
):
    """
    绘制收益率分布直方图
    
    参数:
        df: 股票数据DataFrame
        file_name: 图片文件名
    """
    plt.figure(figsize=(12, 6))

    plt.hist(
        df["return"].dropna(),
        bins=50
    )

    mean_return = df["return"].mean()
    plt.axvline(
        mean_return,
        color="red",
        linestyle="--",
        label=f"Mean: {mean_return:.4f}"
    )

    plt.legend()
    plt.title("Return Distribution")
    plt.xlabel("Return")
    plt.ylabel("Frequency")    
    utils.save_plot(plt.gcf(), file_name)
    plt.show()

def plot_rsi(
    df,
    file_name: str,
):
    """
    绘制RSI指标
    
    参数:
        df: 股票数据DataFrame
        file_name: 图片文件名
    """
    plt.figure(figsize=(12, 6))

    plt.plot(
        df.index,
        df["RSI"],
        label="RSI"
    )

    plt.axhline(
        70,
        linestyle="--",
        label="Overbought(70)"
    )

    plt.axhline(
        30,
        linestyle="--",
        label="Oversold(30)"
    )

    plt.title("RSI Indicator")

    plt.ylim(0,100)

    plt.legend()

    plt.xticks(rotation=45)

    plt.tight_layout()

    utils.save_plot(plt.gcf(), file_name)

    plt.show()


def plot_macd(
    df,
    file_name: str,
):
    """
    绘制MACD指标
    
    参数:
        df: 股票数据DataFrame
        file_name: 图片文件名
    """
    plt.figure(figsize=(12, 6))

    plt.plot(
        df.index,
        df["DIF"],
        label="DIF"
    )

    plt.plot(
        df.index,
        df["DEA"],
        label="DEA"
    )

    colors = [
        "red" if value >= 0 else "green"
        for value in df["MACD"]
    ]
    plt.bar(
        df.index,
        df["MACD"],
        color=colors,
    )

    plt.axhline(
        0,
        linestyle="--"
    )
    plt.title("MACD Indicator")

    red_patch = Patch(
        color="red",
        label="MACD Positive"
    )

    green_patch = Patch(
        color="green",
        label="MACD Negative"
    )

    plt.legend(
        handles=[
            plt.Line2D([], [], label="DIF"),
            plt.Line2D([], [], label="DEA"),
            red_patch,
            green_patch
        ]
    )
    plt.xticks(rotation=45)

    plt.tight_layout()

    utils.save_plot(plt.gcf(), file_name)

    plt.show()


def plot_compare(stock_pool):
    """
    绘制股票池比较收盘价
    
    参数:
        stock_pool: 股票池对象
    """
    plt.figure(figsize=(12, 6))
    for stock in stock_pool.stocks:
        plt.plot(
            stock.df.index,
            stock.df["close"],
            label=stock.file_name.replace(".csv", "")
        )
    plt.title("Close Price Comparison")
    plt.legend()
    plt.xticks(rotation=45)
    plt.tight_layout()
    utils.save_plot(plt.gcf(), "compare_close_price")
    plt.show()


def plot_drawdown(stock):
    """回撤曲线"""
    drawdown = risk_analysis.calculate_drawdown(stock.df)
    max_drawdown = drawdown.min()

    plt.figure(figsize=(12, 6))
    plt.plot(drawdown.index, drawdown)
    plt.scatter(
        drawdown.idxmin(),
        max_drawdown
    )
    plt.title("Drawdown Curve")
    plt.xlabel("Date")
    plt.ylabel("Drawdown")
    plt.grid()
    plt.xticks(rotation=45)
    plt.tight_layout()
    utils.save_plot(plt.gcf(), "drawdown_curve")
    plt.show()

def plot_risk_return(risk_df):
    plt.figure(figsize=(12,6))
    plt.scatter(risk_df["volatility"], risk_df["total_return"])

    for i,row in risk_df.iterrows():
        plt.text(
            row["volatility"],
            row["total_return"],
            row["stock"].replace(".csv", "")
        )

    plt.xlabel("Volatility")
    plt.ylabel("Total Return")
    plt.title("Risk-Return Scatter Plot")
    plt.grid()
    plt.tight_layout()
    utils.save_plot(plt.gcf(), "risk_return")
    plt.show()


def plot_portfolio_curve(portfolio):
    """
    绘制投资组合净值曲线
    
    参数:
        portfolio: 投资组合对象
    """
    returns = portfolio.calculate_return()
    nav = (1 + returns).cumprod()
    plt.figure(figsize=(12,6))
    
    plt.plot(nav.index, nav.values)
    plt.title("Portfolio Net Value Curve")
    plt.xlabel("Date")
    plt.ylabel("Net Asset Value")
    plt.grid()
    plt.xticks(rotation=45)
    plt.tight_layout()
    utils.save_plot(plt.gcf(), "portfolio_curve")
    plt.show()


def plot_portfolio_return_distribution(portfolio): 
    """
    绘制组合每日收益率分布
    """

    returns = (portfolio.calculate_return())

    plt.figure(figsize=(12,6))
    plt.hist(
        returns,
        bins=50
    )
    plt.title(
        "Portfolio Daily Return Distribution"
    )
    plt.xlabel(
        "Daily Return"
    )
    plt.ylabel(
        "Frequency"
    )
    # 设置横轴为百分比显示
    plt.gca().xaxis.set_major_formatter(
        PercentFormatter(1)
    )

    plt.tight_layout()
    utils.save_plot(plt.gcf(), "portfolio_return_distribution")
    plt.show()


def plot_performance_curve(portfolio, benchmark):
    """
    绘制组合和基准的净值曲线
    """

    portfolio_nav = (1 + portfolio.calculate_return()).cumprod()
    benchmark_nav = (1 + benchmark.calculate_return()).cumprod()
    plt.figure(figsize=(12,6))
    plt.plot(portfolio_nav.index, portfolio_nav.values, label="Portfolio")
    plt.plot(benchmark_nav.index, benchmark_nav.values, label="Benchmark")
    plt.title("Portfolio vs Benchmark")
    plt.xlabel("Date")
    plt.ylabel("Net Asset Value")
    plt.grid()
    plt.xticks(rotation=45)
    plt.tight_layout()
    utils.save_plot(plt.gcf(), "performance_curve")
    plt.show()